import type { Reactive } from '../types/ui-config';

export function isGetter<T>(value: Reactive<T>): value is () => T {
  return typeof value === 'function';
}
