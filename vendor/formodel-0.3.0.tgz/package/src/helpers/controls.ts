import { CUSTOM_FIELD } from '../consts/custom-field';
import type {
  ControlNodes,
  CustomControlNode,
  CustomFieldNode,
  RepeatingGroupNode,
  UiFormGroupConfig,
} from '../types/ui-config';

type ControlOptions<TNode> = Omit<TNode, 'type' | 'label'>;

type NodeValue<N> = N extends { readonly __value?: infer V } ? V : never;

export function text(
  label: string,
  opts?: ControlOptions<ControlNodes['text']>,
): ControlNodes['text'] {
  return { ...opts, type: 'text', label };
}

export function textarea(
  label: string,
  opts?: ControlOptions<ControlNodes['textarea']>,
): ControlNodes['textarea'] {
  return { ...opts, type: 'textarea', label };
}

export function number(
  label: string,
  opts?: ControlOptions<ControlNodes['number']>,
): ControlNodes['number'] {
  return { ...opts, type: 'number', label };
}

export function email(
  label: string,
  opts?: ControlOptions<ControlNodes['email']>,
): ControlNodes['email'] {
  return { ...opts, type: 'email', label };
}

export function password(
  label: string,
  opts?: ControlOptions<ControlNodes['password']>,
): ControlNodes['password'] {
  return { ...opts, type: 'password', label };
}

export function phone(
  label: string,
  opts?: ControlOptions<ControlNodes['tel']>,
): ControlNodes['tel'] {
  return { ...opts, type: 'tel', label };
}

export function url(label: string, opts?: ControlOptions<ControlNodes['url']>): ControlNodes['url'] {
  return { ...opts, type: 'url', label };
}

export function date(
  label: string,
  opts?: ControlOptions<ControlNodes['date']>,
): ControlNodes['date'] {
  return { ...opts, type: 'date', label };
}

export function file(
  label: string,
  opts?: ControlOptions<ControlNodes['file']>,
): ControlNodes['file'] {
  return { ...opts, type: 'file', label };
}

export function select(
  label: string,
  options: ControlNodes['select']['options'],
  opts?: Omit<ControlNodes['select'], 'type' | 'label' | 'options'>,
): ControlNodes['select'] {
  return { ...opts, type: 'select', label, options };
}

export function multiselect(
  label: string,
  options: ControlNodes['select']['options'],
  opts?: Omit<ControlNodes['select'], 'type' | 'label' | 'options' | 'multiple'>,
): ControlNodes['select'] {
  return { ...opts, type: 'select', label, options, multiple: true };
}

export function radio(
  options: ControlNodes['radio']['options'],
  opts?: Omit<ControlNodes['radio'], 'type' | 'options'>,
): ControlNodes['radio'] {
  return { ...opts, type: 'radio', options };
}

export function checkbox(
  label: string,
  value: unknown = true,
  opts?: Omit<ControlNodes['checkbox'], 'type' | 'label' | 'value'>,
): ControlNodes['checkbox'] {
  return { ...opts, type: 'checkbox', label, value };
}

export function array<TItem>(
  itemConfig: UiFormGroupConfig<TItem>,
  opts?: Omit<RepeatingGroupNode<TItem>, 'type' | 'itemConfig'>,
): RepeatingGroupNode<TItem> {
  return { ...opts, type: 'array', itemConfig };
}

export function customInputType<N extends CustomControlNode<unknown, Record<string, unknown>>>(
  kind: string,
): (props: N['props']) => CustomControlNode<NodeValue<N>, N['props']> {
  return (props) => ({ type: kind, props });
}

export function customField(): CustomFieldNode {
  return { type: CUSTOM_FIELD };
}
