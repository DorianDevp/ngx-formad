import { CUSTOM_FIELD } from '../consts/custom-field';
import type {
  ControlNodes,
  Reactive,
  CustomControlNode,
  CustomFieldNode,
  RepeatingGroupNode,
  UiFormGroupConfig,
} from '../types/ui-config';

type ControlOptions<TNode> = Omit<TNode, 'type' | 'label'>;

type NodeValue<N> = N extends { readonly __value?: infer V } ? V : never;

type NodeProps<N> = N extends { props: Reactive<infer P extends Record<string, unknown>> } ? P : never;

export function text(
  label: Reactive<string>,
  opts?: ControlOptions<ControlNodes['text']>,
): ControlNodes['text'] {
  return { ...opts, type: 'text', label };
}

export function textarea(
  label: Reactive<string>,
  opts?: ControlOptions<ControlNodes['textarea']>,
): ControlNodes['textarea'] {
  return { ...opts, type: 'textarea', label };
}

export function number(
  label: Reactive<string>,
  opts?: ControlOptions<ControlNodes['number']>,
): ControlNodes['number'] {
  return { ...opts, type: 'number', label };
}

export function email(
  label: Reactive<string>,
  opts?: ControlOptions<ControlNodes['email']>,
): ControlNodes['email'] {
  return { ...opts, type: 'email', label };
}

export function password(
  label: Reactive<string>,
  opts?: ControlOptions<ControlNodes['password']>,
): ControlNodes['password'] {
  return { ...opts, type: 'password', label };
}

export function phone(
  label: Reactive<string>,
  opts?: ControlOptions<ControlNodes['tel']>,
): ControlNodes['tel'] {
  return { ...opts, type: 'tel', label };
}

export function url(label: Reactive<string>, opts?: ControlOptions<ControlNodes['url']>): ControlNodes['url'] {
  return { ...opts, type: 'url', label };
}

export function date(
  label: Reactive<string>,
  opts?: ControlOptions<ControlNodes['date']>,
): ControlNodes['date'] {
  return { ...opts, type: 'date', label };
}

export function file(
  label: Reactive<string>,
  opts?: ControlOptions<ControlNodes['file']>,
): ControlNodes['file'] {
  return { ...opts, type: 'file', label };
}

export function select(
  label: Reactive<string>,
  options: ControlNodes['select']['options'],
  opts?: Omit<ControlNodes['select'], 'type' | 'label' | 'options'>,
): ControlNodes['select'] {
  return { ...opts, type: 'select', label, options };
}

export function multiselect(
  label: Reactive<string>,
  options: ControlNodes['select']['options'],
  opts?: Omit<ControlNodes['select'], 'type' | 'label' | 'options' | 'multiple'>,
): ControlNodes['select'] {
  return { ...opts, type: 'select', label, options, multiple: true };
}

export function radio(
  options: ControlNodes['radio']['options'],
  opts?: Omit<ControlNodes['radio'], 'type' | 'options'>,
): ControlNodes['radio'] {
  return { ...opts, type: 'radio', options };
}

export function checkbox(
  label: Reactive<string>,
  value: unknown = true,
  opts?: Omit<ControlNodes['checkbox'], 'type' | 'label' | 'value'>,
): ControlNodes['checkbox'] {
  return { ...opts, type: 'checkbox', label, value };
}

export function array<TItem>(
  itemConfig: UiFormGroupConfig<TItem>,
  opts?: Omit<RepeatingGroupNode<TItem>, 'type' | 'itemConfig'>,
): RepeatingGroupNode<TItem> {
  return { ...opts, type: 'array', itemConfig };
}

export function customInputType<N extends CustomControlNode<unknown, Record<string, unknown>>>(
  kind: string,
): (props: Reactive<NodeProps<N>>) => CustomControlNode<NodeValue<N>, NodeProps<N>> {
  return (props) => ({ type: kind, props });
}

export function customField(): CustomFieldNode {
  return { type: CUSTOM_FIELD };
}
