export const FORK: unique symbol = Symbol('formodel.fork');
