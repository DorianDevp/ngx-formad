import { CUSTOM_FIELD } from '../consts/custom-field';

export type Reactive<T> = T | (() => T);

export type ControlType =
  | 'text'
  | 'textarea'
  | 'number'
  | 'email'
  | 'password'
  | 'tel'
  | 'url'
  | 'select'
  | 'date'
  | 'radio'
  | 'checkbox'
  | 'file';

export type BaseFormControlNode = {
  label?: Reactive<string>;
  header?: Reactive<string>;
  type: ControlType;
  description?: Reactive<string>;
  placeholder?: Reactive<string>;
  innerHTML?: Reactive<string>;
  fullWidth?: Reactive<boolean>;
};

export type TextFormControlNode = BaseFormControlNode & {
  label: Reactive<string>;
  type: 'text';
};

export type TextareaFormControlNode = BaseFormControlNode & {
  label: Reactive<string>;
  type: 'textarea';
  rows?: Reactive<number>;
};

export type NumberFormControlNode = BaseFormControlNode & {
  label: Reactive<string>;
  type: 'number';
  min?: Reactive<number>;
  max?: Reactive<number>;
  step?: Reactive<number>;
};

export type EmailFormControlNode = BaseFormControlNode & {
  label: Reactive<string>;
  type: 'email';
};

export type PasswordFormControlNode = BaseFormControlNode & {
  label: Reactive<string>;
  type: 'password';
};

export type TelFormControlNode = BaseFormControlNode & {
  label: Reactive<string>;
  type: 'tel';
};

export type UrlFormControlNode = BaseFormControlNode & {
  label: Reactive<string>;
  type: 'url';
};

export type SelectFormControlNode = BaseFormControlNode & {
  label: Reactive<string>;
  type: 'select';
  options: Reactive<{ value: unknown; description: string }[]>;
  multiple?: Reactive<boolean>;
};

export type DateFormControlNode = BaseFormControlNode & {
  label: Reactive<string>;
  type: 'date';
  limit?: Reactive<{ min: Date; max: Date }>;
};

export type RadioFormControlNode = BaseFormControlNode & {
  type: 'radio';
  options: Reactive<{ value: unknown; label: string }[]>;
};

export type CheckboxFormControlNode = BaseFormControlNode & {
  type: 'checkbox';
  label?: Reactive<string>;
  value: unknown;
};

export type FileFormControlNode = BaseFormControlNode & {
  label: Reactive<string>;
  type: 'file';
  accept?: Reactive<string>;
  multiple?: Reactive<boolean>;
  maxFiles?: Reactive<number>;
  maxSize?: Reactive<number>;
};

export type CustomControlNode<Value, Props extends Record<string, unknown>> = {
  type: string;
  props: Reactive<Props>;
  readonly __value?: Value;
};

export type CustomFieldNode = {
  type: typeof CUSTOM_FIELD;
};

export interface DefaultControlNodes {
  text: TextFormControlNode;
  textarea: TextareaFormControlNode;
  number: NumberFormControlNode;
  email: EmailFormControlNode;
  password: PasswordFormControlNode;
  tel: TelFormControlNode;
  url: UrlFormControlNode;
  select: SelectFormControlNode;
  date: DateFormControlNode;
  radio: RadioFormControlNode;
  checkbox: CheckboxFormControlNode;
  file: FileFormControlNode;
  custom: CustomFieldNode;
}

export interface ControlNodeOverrides {}

export interface CustomControlNodes {}

export type ControlNodes = Omit<DefaultControlNodes, keyof ControlNodeOverrides> &
  ControlNodeOverrides;

export type UiFormControlNode = ControlNodes[keyof ControlNodes];

export type CustomNode<Value> = Extract<
  CustomControlNodes[keyof CustomControlNodes],
  { readonly __value?: Value }
>;

export type ArrayItemActions = {
  addable?: Reactive<boolean>;
  removable?: Reactive<boolean>;
  replaceable?: Reactive<boolean>;
  sortable?: Reactive<boolean>;
  addLabel?: Reactive<string>;
  removeLabel?: Reactive<string>;
};

export type RepeatingGroupNode<TItem> = ArrayItemActions & {
  type: 'array';
  label?: Reactive<string>;
  header?: Reactive<string>;
  description?: Reactive<string>;
  fullWidth?: Reactive<boolean>;
  minItems?: Reactive<number>;
  maxItems?: Reactive<number>;
  itemConfig: UiFormGroupConfig<TItem>;
};

export type ArrayFormControlNode<TItem> =
  | RepeatingGroupNode<TItem>
  | ControlNodes['select']
  | ControlNodes['file'];

export interface UiFormGroupNode<T> {
  label: string;
  maxCols: number;
  controlsConfig: UiFormGroupConfig<T>;
}

export type ConfigurableKey<T, K extends keyof T & (string | number)> = T[K] extends null | undefined
    ? never
    : T[K] extends (...args: never[]) => unknown
      ? never
      : K;

export type UiFormGroupConfig<T> = {
  [K in Extract<keyof T, string | number> as ConfigurableKey<T, K>]: T[K] extends Date
    ? UiFormControlNode | CustomNode<T[K]>
    : T[K] extends readonly (infer U)[]
      ? ArrayFormControlNode<U> | CustomFieldNode | CustomNode<T[K]>
      : T[K] extends Record<string, unknown>
        ? UiFormGroupNode<T[K]>
        : UiFormControlNode | CustomNode<T[K]>;
};
