import { FORK } from '../consts/fork';
import type {
  ArrayFormControlNode,
  ConfigurableKey,
  CustomFieldNode,
  CustomNode,
  UiFormControlNode,
  UiFormGroupConfig,
  UiFormGroupNode,
} from './ui-config';

export type UnknownRecord = Record<string | number, unknown>;

export type ElementOf<T> = T extends readonly (infer U)[] ? U : never;

export type RemainingKeys<R> = keyof {
  [K in keyof R as K extends string | number ? ConfigurableKey<R, K> : never]: 0;
};

export type GroupMeta<T> = Pick<UiFormGroupNode<T>, 'label' | 'maxCols'>;

export type ChildBuilder<T extends UnknownRecord> = (builder: UiFormBuilder<T>) => UiFormGroupConfig<T>;

export type BuilderResult<TRoot extends UnknownRecord, R> = [RemainingKeys<R>] extends [never]
  ? UiFormGroupConfig<TRoot>
  : R extends UnknownRecord
    ? UiFormBuilder<TRoot, R>
    : never;

export type ScalarFieldFn<TRoot extends UnknownRecord, R extends UnknownRecord, K extends keyof R> = (
  node: UiFormControlNode | CustomNode<R[K]>,
) => BuilderResult<TRoot, Omit<R, K>>;

export type ArrayFieldFn<TRoot extends UnknownRecord, R extends UnknownRecord, K extends keyof R> = (
  node: ArrayFormControlNode<ElementOf<R[K]>> | CustomFieldNode | CustomNode<R[K]>,
) => BuilderResult<TRoot, Omit<R, K>>;

export type ObjectFieldFn<
  TRoot extends UnknownRecord,
  R extends UnknownRecord,
  K extends keyof R,
> = R[K] extends UnknownRecord
  ? (meta: GroupMeta<R[K]>, childBuilder: ChildBuilder<R[K]>) => BuilderResult<TRoot, Omit<R, K>>
  : never;

export type FieldFn<
  TRoot extends UnknownRecord,
  R extends UnknownRecord,
  K extends keyof R,
> = R[K] extends Date
  ? ScalarFieldFn<TRoot, R, K>
  : R[K] extends readonly unknown[]
    ? ArrayFieldFn<TRoot, R, K>
    : R[K] extends UnknownRecord
      ? ObjectFieldFn<TRoot, R, K>
      : ScalarFieldFn<TRoot, R, K>;

export type UiFormBuilder<
  TRoot extends UnknownRecord,
  R extends UnknownRecord = TRoot,
> = {
  [K in Extract<keyof R, string | number> as ConfigurableKey<R, K>]: FieldFn<TRoot, R, K>;
} & ForkSlot<TRoot, R>;

export type ModelEntry<T> = [keyof T & string, unknown];

export type ForkSlot<TRoot extends UnknownRecord, R extends UnknownRecord = TRoot> = {
  [FORK]: () => UiFormBuilder<TRoot, R>;
};
