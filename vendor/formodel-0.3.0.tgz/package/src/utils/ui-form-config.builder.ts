import { FORK } from '../consts/fork';
import type { UiFormGroupConfig, UiFormGroupNode } from '../types/ui-config';
import type {
  ChildBuilder,
  ForkSlot,
  GroupMeta,
  ModelEntry,
  UiFormBuilder,
  UnknownRecord,
} from '../types/ui-builder';

export class UiFormConfigBuilder {
  static from<TModel extends UnknownRecord>(model: TModel): UiFormBuilder<TModel> {
    const entries = Object.entries(model).filter(
      ([, value]) => value != null && typeof value !== 'function',
    ) as ModelEntry<TModel>[];

    return UiFormConfigBuilder.build<TModel>(entries, {} as UiFormGroupConfig<TModel>);
  }

  static fork<TRoot extends UnknownRecord, R extends UnknownRecord>(
    builder: UiFormBuilder<TRoot, R>,
  ): UiFormBuilder<TRoot, R> {
    const fork: (() => UiFormBuilder<TRoot, R>) | undefined = builder[FORK];

    if (!fork) {
      throw new Error('formodel: fork() expects an in-progress builder, not a finished config.');
    }

    return fork();
  }

  private static build<TRoot extends UnknownRecord>(
    entries: ModelEntry<TRoot>[],
    nodes: UiFormGroupConfig<TRoot>,
  ): UiFormBuilder<TRoot> {
    const agg = {} as UiFormBuilder<TRoot>;

    for (const [key, value] of entries) {
      assign(agg, key as keyof UiFormBuilder<TRoot>, UiFormConfigBuilder.make(value, key, agg, nodes));
    }

    assignFork(agg, () =>
      UiFormConfigBuilder.build<TRoot>(
        entries.filter(([key]) => Object.hasOwn(agg, key)),
        { ...nodes },
      ),
    );

    return agg;
  }

  private static make<TRoot extends UnknownRecord>(
    value: unknown,
    key: keyof TRoot & string,
    agg: UiFormBuilder<TRoot>,
    nodes: UiFormGroupConfig<TRoot>,
  ): UiFormBuilder<TRoot>[keyof UiFormBuilder<TRoot>] {
    const childModel = isObjectField(value) ? value : undefined;
    const slot = key as keyof UiFormGroupConfig<TRoot>;

    const method = (...args: unknown[]): UiFormBuilder<TRoot> | UiFormGroupConfig<TRoot> => {
      if (childModel) {
        const [meta, childBuilder] = args as [GroupMeta<UnknownRecord>, ChildBuilder<UnknownRecord>];
        const groupNode: UiFormGroupNode<UnknownRecord> = {
          ...meta,
          controlsConfig: childBuilder(UiFormConfigBuilder.from(childModel)),
        };
        assign(nodes, slot, groupNode as UiFormGroupConfig<TRoot>[typeof slot]);
      } else {
        assign(nodes, slot, args[0] as UiFormGroupConfig<TRoot>[typeof slot]);
      }

      Reflect.deleteProperty(agg, key);

      return Object.keys(agg).length > 0 ? agg : nodes;
    };

    return method as UiFormBuilder<TRoot>[keyof UiFormBuilder<TRoot>];
  }
}

// dynamic model fields
function assign<T, K extends keyof T>(target: T, key: K, value: T[K]): void {
  target[key] = value;
}

// infra symbol
function assignFork<TRoot extends UnknownRecord, R extends UnknownRecord>(
  target: ForkSlot<TRoot, R>,
  value: () => UiFormBuilder<TRoot, R>,
): void {
  target[FORK] = value;
}

function isObjectField(value: unknown): value is UnknownRecord {
  return (
    typeof value === 'object' &&
    value !== null &&
    !Array.isArray(value) &&
    !(value instanceof Date)
  );
}
